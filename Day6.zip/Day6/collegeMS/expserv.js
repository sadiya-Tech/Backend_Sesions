const express = require("express");
const mong = require('mongoose');

const app = express();
app.use(express.json()); // middleware to parse JSON bodies

// Database connection
mong.connect("mongodb://127.0.0.1:27017/Collegedbs1")
  .then(() => console.log("Connected to Collegedbs database successfully!"))
  .catch((err) => console.error("Database connection error:", err));

// Schemas
const teacherSchema = new mong.Schema({
  name: { type: String, required: true },
  subject: { type: String, required: true },
  experience: { type: Number, default: 0 }
});

const studentSchema = new mong.Schema({
  name: { type: String, required: true },
  rollno: { type: Number, required: true },
  email: { type: String, default: "xyz@gmail.com" }
});

const courseSchema = new mong.Schema({
  title: { type: String, required: true },
  code: { type: Number, required: true },
  credits: { type: Number, default: 100 }
});

// Models
const Teacher = mong.model('Teacher', teacherSchema);
const Student = mong.model('Student', studentSchema);
const Course = mong.model('Course', courseSchema);


//Get Method implemention 

app.get('/api/students', async (req, res) => {
    try {
        const liststudents = await Student.find();
        res.status(200).json({
            message1:"list of students",
            data : liststudents
        });
    } catch (error) {
        res.status(404).json({ error: error.message });
    }
});

// GET a Specific Student by ID
app.get('/api/students/:id', async (req, res) => {
    try {
        const student = await Student.findById(req.params.id)
        //4 = > True
        if (!student) {
            return res.status(404).json({ message: "Student not found" });
        }
        
        res.status(200).json(student);
    } catch (error) {
        // Catches casting errors if the passed ID string is invalid
        res.status(500).json({ error: error.message });
    }
});



// UPDATE a Student (PUT)
app.put('/api/students/:id', async (req, res) => {
    try {
        // { new: true } returns the modified document instead of the old one
        // { runValidators: true } ensures the update updates match your schema definitions
        const updatedStudent = await Student.findByIdAndUpdate(
            req.params.id, 
            req.body
        )

        if (!updatedStudent) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.status(200).json({msg:"student updated",
                      data:req.body
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


// 🚀 NEW: Route to Add and Save a Student

app.post("/api/students", async (req, res) => {
  try {
    // 1. Create a new student instance using data sent in the request body
    const newStudent = new Student({
      name: req.body.name,
      rollno: req.body.rollno,
      email: req.body.email // If empty, it defaults to "xyz@gmail.com"
    });

    // 2. Save the document to the MongoDB database
    const savedStudent = await newStudent.save();

    // 3. Send back a success response
    res.status(201).json({
      message: "Student added successfully!",
      data: savedStudent
    });
  } catch (error) {
    // Handle validation or connection errors
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/students/:id', async (req, res) => {
    try {
        const deletedStudent = await Student.findByIdAndDelete(req.params.id);

        if (!deletedStudent) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.status(200).json({ 
            message: "Student record deleted successfully", 
            deletedStudent 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


// Start server
app.listen(3000, () => {
  console.log("Server running on port 3000");
});
