//JS- TOmake website more intractive,more responsive and add functionality.
//It is programming language
//Fronted end-
console.log("hello sadiya");
//varible---
//data type->Integer,string,boolean,array,object
//syntax->var varname=value; let varible=value; const varible=value;
let x=20
console.log( "the integer value is",x);
const name="sadiya";
console.log("the string value is",name);
console.log(typeof(x));
console.log(typeof(sadiya));
console.log ("boolean value is",true);
console.log("array value is",[1,2,3,4,5]);
console.log("object value is",{name:"sadiya",age:20});

var arr=[1,2,3,4,5];
console.log(arr[0]);

let s=undefined;
console.log("the undefined value is",s);

let student1={student_name:"sadiya",
     reg_no:20,
    office:['h1','h2','h3']};
    console.log(student1) 
     console.log("student 1 name:",student1.student_name);
//function
function add(a,b){
    return a+b;
}
console.log(function (x,y){
    return x+y;
}(10,20));
    //call back function
    //add sub
    